cp /home/svnayak/Documents/Work/Scripts/prefs.mk .

echo "#########################################"
echo "Running build in......"
pwd
echo "#########################################"

./buildall.sh -S -d
